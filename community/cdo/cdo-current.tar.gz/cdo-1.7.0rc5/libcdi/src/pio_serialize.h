#ifndef SERIALIZE_PIO_H
#define SERIALIZE_PIO_H
/* switch current namespace to use MPI serialization */
void cdiPioSerializeSetMPI();

#endif
