#ifndef PIO_CLIENT_H
#define PIO_CLIENT_H

void
cdiPioClientSetup(int *pioNamespace_, int *pioNamespace);

#endif
