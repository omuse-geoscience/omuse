#define TEST_CHUNK_WRITE 1
#include "cksum_write.c"
