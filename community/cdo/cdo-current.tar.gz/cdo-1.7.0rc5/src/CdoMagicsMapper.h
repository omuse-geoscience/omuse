#ifndef CDO_MAGICS_MAPPER_HH
#define CDO_MAGICS_MAPPER_HH

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/* void FindMagicsStruct ( const char *user_name ); */

int GetMagicsParameterInfo( const char *user_name, char *param_value );

#endif
