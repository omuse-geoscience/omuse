This package installs the ERA5 interface for OMUSE.
